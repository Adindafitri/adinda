<?php 

 $con=new mysqli('localhost:8080','root','crudoperation');

 if($con){
 	echo "connection successfull";
 }else{
 	die(mysqli_error($con));
 }


 ?>
