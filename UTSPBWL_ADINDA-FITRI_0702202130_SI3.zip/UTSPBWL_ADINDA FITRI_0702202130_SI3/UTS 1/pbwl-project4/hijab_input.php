<h2>Tambah Hijab</h2>

<form action="Hijab_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Hijab</td>
            <td><input type="text" name="nama_Hijab"></td>
        </tr>
        <tr>
            <td>Harga Hijab</td>
            <td><input type="text" name="hrg_Hijab"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

<a href="Hijab_tampil.php">Kembali</a>