<h2>Tambah Baju</h2>

<form action="baju_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Baju </td>
            <td><input type="text" name="nama_baju "></td>
        </tr>
        <tr>
            <td>Harga Baju</td>
            <td><input type="text" name="hrg_baju"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

<a href="baju_tampil.php">Kembali</a>