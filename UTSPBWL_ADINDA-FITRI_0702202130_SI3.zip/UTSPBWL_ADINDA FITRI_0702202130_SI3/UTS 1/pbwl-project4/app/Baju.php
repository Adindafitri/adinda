<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Baju extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_Baju";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $nama_Baju = $_POST['nama_Baju'];
        $hrg_Baju = $_POST['hrg_Baju'];

        $sql = "INSERT INTO tb_Baju (nama_Baju, hrg_Baju) VALUES (:nama_Baju, :hrg_Baju)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_Baju", $nama_Baju);
        $stmt->bindParam(":hrg_Baju", $hrg_Baju);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_baju WHERE id_baju=:id_baju";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_baju", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $nama_baju = $_POST['nama_baju'];
        $hrg_baju = $_POST['hrg_baju'];
        $id_baju = $_POST['id_baju'];

        $sql = "UPDATE tb_baju SET nama_baju=:nama_baju, hrg_baju=:hrg_baju WHERE id_baju=:id_baju";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_baju", $nama_baju);
        $stmt->bindParam(":hrg_baju", $hrg_baju);
        $stmt->bindParam(":id_baju", $id_baju);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_baju WHERE id_baju=:id_baju";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_baju", $id);
        $stmt->execute();

    }

}