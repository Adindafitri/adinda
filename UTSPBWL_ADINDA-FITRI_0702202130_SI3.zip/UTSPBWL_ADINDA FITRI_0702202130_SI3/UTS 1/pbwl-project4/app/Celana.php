<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Celana extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_Celana";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $nama_Celana = $_POST['nama_Celana'];
        $hrg_Celana = $_POST['hrg_Celana'];

        $sql = "INSERT INTO tb_Celana (nama_Celana, hrg_Celana) VALUES (:nama_Celana, :hrg_Celana)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_Celana", $nama_Celana);
        $stmt->bindParam(":hrg_Celana", $hrg_Celana);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_Celana WHERE id_celana=:id_celana";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_celana", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $nama_celana = $_POST['nama_celana'];
        $hrg_celana = $_POST['hrg_celana'];
        $id_celana = $_POST['id_celana'];

        $sql = "UPDATE tb_celana SET nama_celana=:nama_celana, hrg_celana=:hrg_celana WHERE id_celana=:id_celana";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_celana", $nama_celana);
        $stmt->bindParam(":hrg_celana", $hrg_celana);
        $stmt->bindParam(":id_celana", $id_celana);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_celana WHERE id_celana=:id_celana";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_celana", $id);
        $stmt->execute();

    }

}