<?php

namespace App;
use Inc\Koneksi as Koneksi;

class hijab
 extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_hijab
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $nama_hijab
         = $_POST['nama_hijab
        '];
        $hrg_hijab
         = $_POST['hrg_hijab
        '];

        $sql = "INSERT INTO tb_hijab
         (nama_hijab
        , hrg_hijab
        ) VALUES (:nama_hijab
        , :hrg_hijab
        )";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_hijab
        ", $nama_hijab
    );
        $stmt->bindParam(":hrg_hijab
        ", $hrg_hijab
    );
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_hijab
         WHERE id_hijab
        =:id_hijab
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_hijab
        ", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $nama_hijab
         = $_POST['nama_hijab
        '];
        $hrg_hijab
         = $_POST['hrg_hijab
        '];
        $id_hijab
         = $_POST['id_hijab
        '];

        $sql = "UPDATE tb_hijab
         SET nama_hijab
        =:nama_hijab
        , hrg_hijab
        =:hrg_hijab
         WHERE id_hijab
        =:id_hijab
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":nama_hijab
        ", $nama_hijab
    );
        $stmt->bindParam(":hrg_hijab
        ", $hrg_hijab
    );
        $stmt->bindParam(":id_hijab
        ", $id_hijab
    );
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_hijab
         WHERE id_hijab
        =:id_hijab
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":id_hijab
        ", $id);
        $stmt->execute();

    }

}