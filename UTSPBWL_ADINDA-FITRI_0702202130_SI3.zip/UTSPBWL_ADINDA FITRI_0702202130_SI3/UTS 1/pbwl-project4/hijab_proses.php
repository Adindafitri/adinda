<?php

require_once "inc/Koneksi.php";
require_once "app/Hijab.php";

$snc = new App\Hijab();

if (isset($_POST['btn_simpan'])) {
    $snc->simpan();
    header("location:index.php?hal=hijab_tampil");
}

if (isset($_POST['btn_update'])) {
    $snc->update();
    header("location:index.php?hal=hijab_tampil");
}