<h2>Tambah Makanan</h2>

<form action="celana_proses.php" method="post">
    <table>

        <tr>
            <td>Nama Celana</td>
            <td><input type="text" name="nama_celana"></td>
        </tr>
        <tr>
            <td>Harga Celana</td>
            <td><input type="text" name="hrg_celana"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>

<a href="celana_tampil.php">Kembali</a>