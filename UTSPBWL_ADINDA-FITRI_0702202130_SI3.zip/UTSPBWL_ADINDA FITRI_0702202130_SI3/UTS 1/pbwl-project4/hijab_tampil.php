<?php

$sna = new App\Hijab;
$rows = $sna->tampil();

?>

<h2>Hijab</h2>

<a href="index.php?hal=snack_input" class="btn">Tambah Hijab</a>

<table>
    <tr>
        <th>ID Hijab</th>
        <th>NAMA Hijab</th>
        <th>HARGA Hijab</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['id_Hijab']; ?></td>
        <td><?php echo $row['nama_Hijab']; ?></td>
        <td><?php echo $row['hrg_Hijab']; ?></td>
        <td><a href="index.php?hal=Hijab_edit&id=<?php echo $row['id_Hijab']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=Hijab_delete&id=<?php echo $row['id_Hijab']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
