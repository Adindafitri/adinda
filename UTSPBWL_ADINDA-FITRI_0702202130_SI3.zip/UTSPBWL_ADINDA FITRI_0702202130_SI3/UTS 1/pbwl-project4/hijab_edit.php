<?php

$id = $_GET['id'];
$snc = new App\Hijab();

$row = $snc->edit($id);
?>

<h2>Edit Hijab</h2>

<form action="Hijab_proses.php" method="post">
    <input type="hidden" name="id_Hijab" value="<?php echo $row['id_Hijab']; ?>">
    <table>
        <tr>
            <td>Nama Hijab</td>
            <td><input type="text" name="nama_Hijab" value="<?php echo $row['nama_Hijab']; ?>"></td>
        </tr>
        <tr>
            <td>Harga Hijab</td>
            <td><input type="text" name="hrg_Hijab" value="<?php echo $row['hrg_Hijab']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>