<?php

$id = $_GET['id'];

$mak = new App\Celana();
$rows = $mak->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?=celana_tampil">Kembali</a>
</div>