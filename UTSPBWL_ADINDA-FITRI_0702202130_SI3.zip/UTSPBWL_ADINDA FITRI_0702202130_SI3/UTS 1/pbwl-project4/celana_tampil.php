<?php

$mak = new App\Celana;
$rows = $mak->tampil();

?>

<h2>Makanan</h2>

<a href="index.php?hal=celana_input" class="btn">Tambah Celana</a>

<table>
    <tr>
        <th>ID Celana</th>
        <th>NAMA Celana</th>
        <th>HARGA Celana</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['id_celana']; ?></td>
        <td><?php echo $row['nama_celana']; ?></td>
        <td><?php echo $row['hrg_celana']; ?></td>
        <td><a href="index.php?hal=celana_edit&id=<?php echo $row['id_celana']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=celana_delete&id=<?php echo $row['id_celana']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
