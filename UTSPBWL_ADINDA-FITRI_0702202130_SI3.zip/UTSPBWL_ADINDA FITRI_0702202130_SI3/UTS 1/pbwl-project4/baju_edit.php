<?php

$id = $_GET['id'];
$min= new App\Baju();

$row = $min->edit($id);
?>

<h2>Edit Baju</h2>

<form action="baju_proses.php" method="post">
    <input type="hidden" name="baju" value="<?php echo $row['id_baju']; ?>">
    <table>
        <tr>
            <td>Nama Baju </td>
            <td><input type="text" name="nama_baju" value="<?php echo $row['nama_baju']; ?>"></td>
        </tr>
        <tr>
            <td>Harga Baju</td>
            <td><input type="text" name="nama_baju" value="<?php echo $row['hrg_baju']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>