<?php

require_once "inc/Koneksi.php";
require_once "app/Baju.php";

$min = new App\baju();

if (isset($_POST['btn_simpan'])) {
    $min->simpan();
    header("location:index.php?hal=baju_tampil");
}

if (isset($_POST['btn_update'])) {
    $min->update();
    header("location:index.php?hal=baju_tampil");
}