<?php

$id = $_GET['id'];
$mak= new App\Celana();

$row = $mak->edit($id);
?>

<h2>Edit Celana</h2>

<form action="celana_proses.php" method="post">
    <input type="hidden" name="id_makanan" value="<?php echo $row['id_celana']; ?>">
    <table>
        <tr>
            <td>Nama Celana</td>
            <td><input type="text" name="nama_celana" value="<?php echo $row['nama_celana']; ?>"></td>
        </tr>
        <tr>
            <td>Harga Celana</td>
            <td><input type="text" name="hrg_celana" value="<?php echo $row['hrg_celana']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>