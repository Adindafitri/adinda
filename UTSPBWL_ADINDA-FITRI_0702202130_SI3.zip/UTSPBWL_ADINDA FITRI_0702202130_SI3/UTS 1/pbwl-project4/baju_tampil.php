<?php

$min = new App\Baju;
$rows = $min->tampil();

?>

<h2>Baju</h2>

<a href="index.php?hal=Baju_input" class="btn">Tambah Baju</a>

<table>
    <tr>
        <th>ID Baju</th>
        <th>NAMA Baju</th>
        <th>HARGA Baju</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['id_Baju']; ?></td>
        <td><?php echo $row['nama_Baju']; ?></td>
        <td><?php echo $row['hrg_Baju']; ?></td>
        <td><a href="index.php?hal=Baju_edit&id=<?php echo $row['id_Baju']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=Baju_delete&id=<?php echo $row['id_Baju']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
