<h2>Home</h2>

<div class="info">Selamat datang, <strong>DI TOKO PAKAIAN WANITA LENGKAP ADINDA</strong></div>
<img src="layouts/assets/img/gambar.jpg" alt="">