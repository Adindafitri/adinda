CREATE TABLE tb_celana (
  id_celana int(50) NOT NULL AUTO_INCREMENT,
  nama_celana varchar(100) NOT NULL,
  hrg_celana varchar(50) NOT NULL,
  PRIMARY KEY(id_celana)
);
CREATE TABLE tb_baju (
  id_baju int(50) NOT NULL AUTO_INCREMENT,
  nama_baju varchar(100) NOT NULL,
  hrg_baju varchar(50) NOT NULL,
  PRIMARY KEY(id_baju)
);
CREATE TABLE tb_hijab (
  id_hijab int(50) NOT NULL AUTO_INCREMENT,
  nama_hijab varchar(100) NOT NULL,
  hrg_hijab varchar(50) NOT NULL,
  PRIMARY KEY(id_hijab)
);
